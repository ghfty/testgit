package com.mp.bean;

public class SensitiveWord {

	private String word;

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public SensitiveWord(String word) {
		super();
		this.word = word;
	}

	public SensitiveWord() {
		super();
		// TODO Auto-generated constructor stub
	}
}
